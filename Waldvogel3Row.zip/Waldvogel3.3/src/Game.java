public class Game {
    boolean AI;
    Player player1 = new Player();
    Player player2 = new Player();
    final int[][] winComb = {
            {0, 1, 2}, {3, 4, 5}, {6, 7, 8}, {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, {0, 4, 8}, {2, 4, 6}
    };

    public Game(boolean AI) {
        this.AI = AI;
    }

    public boolean isTie(){
        boolean tie = false;
        int fieldCount = 0;
        for(int i = 0; i < 9; i++){
            if(player1.fieldsSet[i] || player2.fieldsSet[i]){
                fieldCount++;
            }
        }
        if(fieldCount >= 9){
            System.out.println("The game ended in a tie!");
            tie = true;
        }
        return tie;
    }

    public void generateField() {
        int index = 0;
        System.out.println("\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n");
        for (int row = 1; row < 4; row++) {
            for (int i = 0; i < 3; i++) {
                index++;
                if (i == 2) {
                    if (player1.fieldsSet[index - 1]) {
                        System.out.print("x\n");
                    } else if (player2.fieldsSet[index - 1]) {
                        System.out.printf("o\n");
                    } else {
                        System.out.printf(" \n");
                    }
                } else {
                    if (player1.fieldsSet[index - 1]) {
                        System.out.print("x");
                    } else if (player2.fieldsSet[index - 1]) {
                        System.out.printf("o");
                    } else {
                        System.out.printf(" ");
                    }
                    System.out.printf("|");
                }
            }
            if(row != 3) {
                System.out.println("-+-+-");
            }else{
                System.out.println("\n");
            }
        }
    }

    public boolean hasWon(){
        boolean won = false;
        for(int i = 0; i < winComb.length; i++){
            if(player1.fieldsSet[winComb[i][0]] && player1.fieldsSet[winComb[i][1]] && player1.fieldsSet[winComb[i][2]]){
                generateField();
                System.out.println("Player 1 won!");
                won = true;
            }
            if(player2.fieldsSet[winComb[i][0]] && player2.fieldsSet[winComb[i][1]] && player2.fieldsSet[winComb[i][2]]){
                generateField();
                System.out.println("Player 2 won!");
                won = true;
            }
        }
        return won;
    }
}
