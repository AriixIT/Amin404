import java.util.Scanner;

public class Player {
    boolean fieldsSet[] = new boolean[9];
    String name;
    int lastField;

    public boolean AIspecialCase(Player player1){
        int[][] winComb = Main.game.winComb;
        boolean almostWon = false;


        for(int i = 0; i < winComb.length; i++){
            if((player1.fieldsSet[winComb[i][0]] && player1.fieldsSet[winComb[i][1]] && !isLastFieldSet(winComb[i][2])) || (player1.fieldsSet[winComb[i][1]] && player1.fieldsSet[winComb[i][2]] && !isLastFieldSet(winComb[i][0])) || (player1.fieldsSet[winComb[i][0]] && player1.fieldsSet[winComb[i][2]] && !isLastFieldSet(winComb[i][1]))){
                if(!player1.fieldsSet[winComb[i][0]]){
                    lastField = winComb[i][0];
                }

                if(!player1.fieldsSet[winComb[i][1]]){
                    lastField = winComb[i][1];
                }
                if(!player1.fieldsSet[winComb[i][2]]){
                    lastField = winComb[i][2];
                }
                almostWon = true;
                return almostWon;
            }
        }
        return almostWon;
    }
    public void AIsetField(){
        boolean err;
        int field = 0;
        do {
            field = (int) (Math.random() * 9 - 1 + 1) + 1;
            field -= 1;
            err = false;
            if(AIspecialCase(Main.game.player1)){
                field = lastField;
            }
            if(AIspecialCase(Main.game.player2)){
                field = lastField;
            }
            if (fieldsSet[field] == true || Main.game.player1.fieldsSet[field] == true) {
                err = true;
            }
        }while(err);
        fieldsSet[field] = true;
    }
    public void setField(){
        boolean err;
        int field = 0;
        Scanner input = new Scanner(System.in);
        do {
            do {
                err = false;
                System.out.println(name + ", which field do you want to set? (1 - 9)");
                try {
                    field = Integer.parseInt(input.nextLine());

                } catch (NumberFormatException e) {
                    System.out.println("This is not a valid number!");
                    err = true;
                }
                if (field > 9) {
                    System.out.println("This field is out of the board!");
                    err = true;
                }
            }while(err);
            if(this == Main.game.player1){
                if(fieldsSet[field - 1] == true || Main.game.player2.fieldsSet[field - 1] == true){
                    System.out.println("This field is already taken!");
                    err = true;
                }
            }
            else if(this == Main.game.player2){
                if(fieldsSet[field - 1] == true || Main.game.player1.fieldsSet[field - 1] == true){
                    System.out.println("This field is already taken!");
                    err = true;
                }
            }

        }while (err);
        fieldsSet[field - 1] = true;
    }

    public boolean isLastFieldSet(int field){
        boolean isSet = false;
        if(this == Main.game.player1){
            if(fieldsSet[field] == true || Main.game.player2.fieldsSet[field] == true){
                isSet = true;
            }
        }
        else if(this == Main.game.player2){
            if(fieldsSet[field] == true || Main.game.player1.fieldsSet[field] == true){
                isSet = true;
            }
        }
        return isSet;
    }
}
