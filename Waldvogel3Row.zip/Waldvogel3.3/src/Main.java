import java.util.Scanner;

public class Main {
    static Game game;
    public static void main(String[] args){
        String name;
        String name2;
        int choice = 0;
        boolean err = false;
        Scanner input = new Scanner(System.in);
        do {
            err = false;
            System.out.println("Do you want to play against a 2nd Player or a AI?\n" +
                    "[1] 2nd Player\n" +
                    "[2] AI");

            try {
                choice = Integer.parseInt(input.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("This is not a valid answer!");
                err = true;
            }
        }while(err);

        System.out.println("Player 1, type in your name:");
        name = input.nextLine();

        if(choice == 2){
            game = new Game(true);
            game.player1.name = name;
        }else{
            System.out.println("Player 2, type in your Name:");
            name2 = input.nextLine();
            game = new Game(false);
            game.player1.name = name;
            game.player2.name = name2;
        }

        Player currPlayer = game.player1;
        do{
            game.generateField();
            if(game.AI && currPlayer == game.player2) {
                currPlayer.AIsetField();
            }else{
                currPlayer.setField();
            }
            if(currPlayer == game.player1){
                currPlayer = game.player2;
            }else{
                currPlayer = game.player1;
            }
        }while(!game.hasWon() && !game.isTie());
    }
}
