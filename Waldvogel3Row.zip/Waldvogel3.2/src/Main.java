import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    //The menu for the user
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        boolean err;
        ArrayList<FileObj> queue = new ArrayList<>();
        
        do{
            System.out.println("\n" +
                    "What do you want to do?\n" +
                    "[1] Add files to the queue\n" +
                    "[2] Run queue\n" +
                    "[3] Exit");
            int choice = Integer.parseInt(input.nextLine());
            
            switch(choice) {
                case 1:
                    System.out.println("Whats the path of the file you want to move/rename? (with the filename)");
                    String path = input.nextLine();
                    FileObj file = new FileObj(path, "", "", "");
                    
                    do {
                        err = false;
                        System.out.println("Choose:\n\n" +
                                "[1] Rename file\n" +
                                "[2] Move (and rename) file");
                        choice = Integer.parseInt(input.nextLine());
                        switch (choice) {
                            case 1:
                                file.rename();
                                break;
                            case 2:
                                file.move();
                                break;
                            default:
                                System.out.println("This is not an option!");
                                err = true;
                        }
                    } while (err);
                    queue.add(file);

                    break;
                    
                case 2:
                    for (int i = 0; i < queue.size(); i++) {
                        queue.get(i).writeFile();
                    }
                    System.out.println("Your files got created!");
                    break;
                    
                case 3:
                    return;
                    
                default:
                    System.out.println("This is not an option!");
            }
        }while(true);
    }
}
