import java.io.*;
import java.util.Scanner;

public class FileObj {
    String pathWithName;
    String pathWithoutName;
    String newPath;
    String newName;
    String content;
    String name;
    boolean delete;

    public FileObj(String path, String newPath, String newName, String content) {
        this.pathWithName = path;
        this.newPath = newPath;
        this.newName = newName;
        this.content = content;
    }

    //Split the full path to the name and the path without the name
    public void setPath() {
        int lastFolderIndex = 0;
        int endIndex = 0;
        StringBuilder path = new StringBuilder(pathWithName);
        StringBuilder fileName = new StringBuilder();
        for (int i = 0; i < pathWithName.length(); i++) {
            if (pathWithName.charAt(i) == '\\' || pathWithName.charAt(i) == '/') {
                lastFolderIndex = i + 1;
            }
        }

        for (int i = lastFolderIndex; i < pathWithName.length(); i++) {
            fileName.append(pathWithName.charAt(i));
            if (pathWithName.charAt(i) == '.') {
                endIndex = i;
            }
        }

        path.delete(lastFolderIndex, pathWithName.length());
        fileName.delete((endIndex - path.length()), fileName.length());
        pathWithoutName = path.toString();
        name = fileName.toString();
    }

    //Change the name of the file
    public void rename() {
        setPath();
        readFile();
        if (newPath == "") {
            newPath = pathWithoutName;
        }
        Scanner input = new Scanner(System.in);
        System.out.println("What is the new name of the file?");
        newName = input.nextLine();
        delete = true;
    }

    //Set a new path and maybe rename
    public void move() {
        setPath();
        readFile();
        Scanner input = new Scanner(System.in);
        System.out.println("What is the new path of the file? (Without name)");
        newPath = input.nextLine();
        if (newPath.charAt(newPath.length() - 1) != '\\') {
            newPath += '\\';
        }
        File file = new File(pathWithName);
        System.out.println("Do you also want to rename the file?\n" +
                "[1] Yes\n" +
                "[2] No");
        int choice = Integer.parseInt(input.nextLine());
        if (choice == 1) {
            rename();
        } else {
            newName = name;
        }
        System.out.println("Do you want to delete the old file?\n" +
                "[1] Yes\n" +
                "[2] No");
        choice = Integer.parseInt(input.nextLine());
        if (choice == 1) {
            delete = true;
        }
    }

    //read out the content of the file
    public void readFile() {
        StringBuilder fileContent = new StringBuilder();
        try {
            BufferedReader br = new BufferedReader(new FileReader(pathWithName));
            String line;
            while ((line = br.readLine()) != null) {
                fileContent.append(line);
                fileContent.append("\n");
            }
            br.close();
        } catch (FileNotFoundException f) {
            System.out.println("The file doesn't exist.");
            System.exit(0);
        } catch (IOException e) {
            System.out.println(e);
        }
        content = fileContent.toString();

    }

    //Put the content in the new file
    public void writeFile() {
        Writer writer = null;

        try {
            writer = new BufferedWriter(new FileWriter(newPath + newName + ".txt"));
            writer.write(content);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                writer.close();
            } catch (IOException ignore) {
                System.out.println(ignore);
                ;
            }
        }
        if (delete) {
            File file = new File(pathWithName);
            file.delete();
        }
    }
}
