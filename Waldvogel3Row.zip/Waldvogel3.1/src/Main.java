import java.io.*;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int choice = 0;
        boolean err;
        if(args.length == 0){
            System.out.println("Please give in the website url as an argument!");
            return;
        }
        try {
        	
            //Get the uri and url and ask, if the user wants to visit the website
            URL urlObject = new URL(args[0]);
            URI uri = urlObject.toURI();
            
            System.out.println("Where do you want to save the file?");
            String path = input.nextLine();
            
            FileWriter fw = new FileWriter(path);
            fw.write(getURLSource(urlObject));
            System.out.println("The source code got written in the file!\n" +
                    "\n" +
                    "\n");
            do {
            	err = false;
	            System.out.println("Do you want to open the webpage?\n" +
	                    "[1] Yes\n" +
	                    "[2] No");
	            try {
	            	choice = Integer.parseInt(input.nextLine());
	            }catch(NumberFormatException e) {
	            	System.out.println("This is not a valid answer!");
	            	err = true;
	            }
            }while(err);
            if (choice == 1) {
                java.awt.Desktop.getDesktop().browse(uri);
            }
        } catch (Exception e) {
            System.out.println("Something went wrong!");
        }

    }

    //Make a connection and get the source code of the page
    public static String getURLSource(URL urlObject) throws IOException {
        URLConnection urlConnection = urlObject.openConnection();
        urlConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");

        return toString(urlConnection.getInputStream());
    }

    //append the source code in a StringBuilder and return it
    private static String toString(InputStream inputStream) throws IOException {
        try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"))) {
            String inputLine;
            StringBuilder stringBuilder = new StringBuilder();
            while ((inputLine = bufferedReader.readLine()) != null) {
                stringBuilder.append(inputLine);
            }

            return stringBuilder.toString();
        }
    }
}
