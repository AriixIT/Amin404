package P2;

public class SequenzZero {
	private int num;
	private String numBin;
	private int sequence;
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getNumBin() {
		return numBin;
	}
	public void setNumBin(String numBin) {
		this.numBin = numBin;
	}
	public SequenzZero(int num) {
		super();
		this.num = num;
	}
	
	public void calculateBinGap(String bin) {
		int sequenceTemp = 0;
		int sequenceFin = 0;
		for(int i = 0; i < bin.length(); i++) {
			if(bin.charAt(i) == '0') {
				sequenceTemp++;
			}
			else if(sequenceTemp > sequenceFin){
				sequenceFin = sequenceTemp;
				sequenceTemp = 0;
			}
		}
		sequence = sequenceFin;
		
	}
	
	public void printOut() {
		System.out.println("Binary number is: " + numBin);
		System.out.println("Length of the longest squence: " + sequence);
	}
	
}
