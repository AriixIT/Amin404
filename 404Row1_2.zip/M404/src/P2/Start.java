package P2;

import java.util.Scanner;

public class Start {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		boolean err = false;
		int num = 0;
		do {
			err = false;
			System.out.println("Type in an integer:");
			try {
				num = Integer.parseInt(input.nextLine());
			}catch(NumberFormatException e) {
				System.out.println("This isn't a number!");
				err = true;
			}
		}while(err);
		
		SequenzZero seq = new SequenzZero(num);
		
		seq.calculateBinGap(calculateBin(num, seq));
		seq.printOut();
		
	}
	
	public static String calculateBin(int num, SequenzZero seq) {
		int numTemp = 0;
		String binTemp = "";
		String bin = "";
		while(num > 0) {
			numTemp = num % 2;
			binTemp = binTemp + numTemp;
			num = num / 2;
		}
		for(int i = 0; i < binTemp.length(); i++) {
			bin = bin + binTemp.charAt(binTemp.length() - (i + 1));
		}
		seq.setNumBin(bin);
		return bin;
	}

}
