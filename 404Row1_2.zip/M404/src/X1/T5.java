package X1;

public class T5 {

    public static void main(String[] args){

        String[] names = new String[3];
        names[0] = "eins";
        names[1] = "zwei";
        names[2] = "drei";
        for(int i = 0; i < 3; i++){
            System.out.println("for: " + names[i]);
        }
        System.out.println("fertig");
    }
}
