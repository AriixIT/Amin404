package O2;


public class Main {
    public static void main(String[] args){
        int[] array = new int[]{30, 32, 3, 675, 3, 30};
        boolean doppelt = false;
        for(int i = 0; i < array.length; i++){
            doppelt = false;
            int zahl = array[i];
            for(int k = 0; k < array.length; k++){
                if(i != k && zahl == array[k]){
                    doppelt = true;
                }
            }
            if(!doppelt){
                System.out.println(zahl);
            }
        }
    }
}